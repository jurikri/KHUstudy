import random

list = [0, 0, 0, 0, 0, 0] # 꼭 필요한 작업인가?

for i in range(len(list)):
        sw = 1

        while sw == 1:
            list[i] = random.randrange(1,7)
            sw = 0

            if i != 0:
                for j in range(i):
                    if list[i] == list[j]:
                        sw = 1
                        print ("Overlapping number!")


print (list)

