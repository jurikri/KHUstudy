"""
Template - Compute the area of a rectangle, given its width and height.
"""

###################################################
# Rectangle area formula
# Student should enter statement on the next line.


###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#28

ms_w = 4
ms_h = 7

calc = ms_w * ms_h

print (calc)