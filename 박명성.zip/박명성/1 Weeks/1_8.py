"""
Template - Compute a name tag, given the first and last name.
"""

###################################################
# Name tag formula
# Student should enter statement on the next line.


###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#My name is Joe Warren.

print ("My name is" + " Joe" + " Warren")