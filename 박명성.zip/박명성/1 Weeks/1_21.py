"""
Template - Compute the area of a triangle (using Heron's formula),
       given its side lengths.
"""

###################################################
# Tests
# Student should uncomment ONLY ONE of the following at a time.

ms_point1 = [0, 0]
ms_point2 = [5, 6]

x_0, y_0 = 0, 0
x_1, y_1 = 3, 4
x_2, y_2 = 1, 1

def ms_run (x_0, x_1, y_0, y_1):
    ms_point1[0] = x_0
    ms_point1[1] = y_0
    ms_point2[0] = x_1
    ms_point2[1] = y_1

    calc = (((ms_point1[0] - ms_point2[0])**2) + ((ms_point1[1] - ms_point2[1])**2))**(0.5)
    distance = calc
    print("The distance from (" + str(x_0) + ", " + str(y_0) +
          ") to (" + str(x_1) + ", " + str(y_1) + ") is " + str(distance) + ".")

    return distance

def herons_formula(ms_a, ms_b, ms_c, ms_s):
    area = (ms_s * (ms_s - ms_a) * (ms_s - ms_b) * (ms_s - ms_c)) ** 0.5
    print("A triangle with vertices (" + str(x_0) + "," + str(y_0) + ")," +
          " (" + str(x_1) + "," + str(y_1) + "), and" +
          " (" + str(x_2) + "," + str(y_2) + ") has an area of " + str(area) + ".")

def value_input (x_0, x_1, x_2, y_0, y_1, y_2):
    ms_a = ms_run(x_0, x_1, y_0, y_1)
    ms_b = ms_run(x_0, x_2, y_0, y_2)
    ms_c = ms_run(x_2, x_1, y_2, y_1)
    ms_s = 0.5 * (ms_a + ms_b + ms_c)

    return ms_a, ms_b, ms_c, ms_s

    # 변수 넣는 함수 넣고
    # 함수 통합하는 함수 만들자

def ms_run2 ():
    ms_a, ms_b, ms_c, ms_s = value_input(x_0, x_1, x_2, y_0, y_1, y_2)
    herons_formula(ms_a, ms_b, ms_c, ms_s)
    print("")

ms_run2 ()

# Test 2 - Select the following lines and use ctrl+shift+k to uncomment.
x_0, y_0 = -2, 4
x_1, y_1 = 1, 6
x_2, y_2 = 2, 1
ms_run2 ()

# Test 3 - Select the following lines and use ctrl+shift+k to uncomment.
x_0, y_0 = 10, 0
x_1, y_1 = 0, 0
x_2, y_2 = 0, 10
ms_run2 ()

###################################################
# Triangle area (Heron's) formula
# Student should enter formulas on the next lines.



###################################################
# Test output
# Student should not change this code.





###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

# Test 1 output:
#A triangle with vertices (0,0), (3,4), and (1,1) has an area of 0.5.

# Test 2 output:
#A triangle with vertices (-2,4), (1,6), and (2,1) has an area of 8.5.

# Test 3 output:
#A triangle with vertices (10,0), (0,0), and (0,10) has an area of 50.0.