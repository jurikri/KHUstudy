"""
Template - Compute a name tag, given the first and last name.
"""

###################################################
# Tests
# Student should uncomment ONLY ONE of the following at a time.

def name (first_name, last_name):
    name_tag = "My name is " + first_name + " " + last_name
    print(name_tag)


# Test 1 - Select the following lines and use ctrl+shift+k to uncomment.
first_name = "Joe"
last_name = "Warren"
name (first_name, last_name)

# Test 2 - Select the following lines and use ctrl+shift+k to uncomment.
first_name = "Scott"
last_name = "Rixner"
name (first_name, last_name)

# Test 3 - Select the following lines and use ctrl+shift+k to uncomment.
first_name = "John"
last_name = "Greiner"
name (first_name, last_name)

###################################################
# Name tag formula
# Student should enter formula on the next line.



###################################################
# Test output
# Student should not change this code.


###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

# Test 1 output:
#My name is Joe Warren.

# Test 2 output:
#My name is Scott Rixner.

# Test 3 output:
#My name is John Greiner.
