"""
Template - Compute the statement about a person's name and age, given the person's name and age.
"""
###################################################
# Name and age formula
# Student should enter statement on the next line.


###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#Joe Warren is 56 years old.


print("Joe Warren is " + str(56) + " years old.")