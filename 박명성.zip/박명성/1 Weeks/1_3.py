ms_w = 4
ms_h = 7

calc = (2 * ms_w) + (2 * ms_h)

print (calc)

"""
Template - Compute the length of a rectangle's perimeter, given its width and height.
"""

###################################################
# Rectangle perimeter formula
# Student should enter statement on the next line.



###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#22