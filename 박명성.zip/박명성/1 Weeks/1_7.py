ms_money = 1000
ms_interest = 7
ms_years = 10

calc = ms_money * ((1 + (0.01 * ms_interest)) ** ms_years)

print (calc)

"""
Template - Compute the future value of a given present value, annual rate, and number of years.
"""

###################################################
# Future value formula
# Student should enter statement on the next line.



###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#1967.15135729