"""
Template - Compute the statement about a person's name and age, given the person's name and age.
"""

###################################################
# Tests
# Student should uncomment ONLY ONE of the following at a time.

def ms_name (name, age):
    statement = name + " is " + str(age) + " years old."
    print(statement)

# Test 1 - Select the following lines and use ctrl+shift+k to uncomment.
name = "Joe Warren"
age = 56
ms_name (name, age)

# Test 2 - Select the following lines and use ctrl+shift+k to uncomment.
name = "Scott Rixner"
age = 40
ms_name (name, age)

# Test 3 - Select the following lines and use ctrl+shift+k to uncomment.
name = "John Greiner"
age = 46
ms_name (name, age)

###################################################
# Name and age formula
# Student should enter formula on the next line.



###################################################
# Test output
# Student should not change this code.

###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

# Test 1 output:
#Joe Warren is 56 years old.

# Test 2 output:
#Scott Rixner is 40 years old.

# Test 3 output:
#John Greiner is 46 years old.
