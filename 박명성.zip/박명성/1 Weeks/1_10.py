ms_point1 = [2, 2] # list
ms_point2 = [5, 6]

calc = (((ms_point1[0] - ms_point2[0])**2) + ((ms_point1[1] - ms_point2[1])**2))**(0.5)

print (calc)

"""
Template - Compute the distance between the points (x0, y0) and (x1, y1).
"""

###################################################
# Distance formula
# Student should enter statement on the next line.

# Hint: You need to use the power operation ** .


###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#5.0