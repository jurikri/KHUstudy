"""
Template - Compute the number of seconds in a given number of hours, minutes, and seconds.
"""

###################################################
# Hours, minutes, and seconds to seconds conversion formula
# Student should enter statement on the next line.



###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#26497

hours = 7
mins = 21
seconds = 37

convert = (hours * 60 ** 2) + (mins * 60 ** 1) + (seconds * 60 ** 0)

print(convert)