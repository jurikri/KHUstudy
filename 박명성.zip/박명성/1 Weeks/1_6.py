"""
Template - Compute the area of a circle, given the length of its radius.
"""

###################################################
# Circle area formula
# Student should enter statement on the next line.


###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#200.96

import math

ms_radius = 8

area_circle = math.pi * ms_radius ** 2

print(area_circle)