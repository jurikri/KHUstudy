"""
Compute the circumference of a circle, given the length of its radius.
"""

###################################################
# Circle circumference formula
# Student should enter statement on the next line.



###################################################
# Expected output
# Student should look at the following comments and compare to printed output.

#50.24
import math

ms_radius = 8 # inches

circumference = 2 * ms_radius * math.pi
circumference_2 = 2 * ms_radius * 3.14

print(circumference)
print(circumference_2)