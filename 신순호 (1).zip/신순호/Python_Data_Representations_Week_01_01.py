"""
Template - String examples
"""

# Fix the four string definitions below.

string1 = "It's just a flesh wound"
string2 = "It's just a flesh wound"
string3 = "It's just a flesh wound"
string4 = """It's just a flesh wound"""

print(string1)
print(string2)
print(string3)
print(string4)