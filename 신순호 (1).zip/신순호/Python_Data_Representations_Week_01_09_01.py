"""
Template - Function that swaps and capitalizes first and last names
"""


def name_swap(name_string):
    """
    Given the string name string of the form "first last", return
    the string "Last First" where both names are now capitalized
    """
    [splited_name_string_first, splited_name_string_second] = name_string.split(" ")
    return splited_name_string_first.capitalize() + " " + splited_name_string_second.capitalize()
    # Enter code here
    pass


# Tests

print(name_swap("joe warren"))
print(name_swap("scott rixner"))
print(name_swap("john greiner"))

# Output

# Warren Joe
# Rixner Scott
# Greiner John