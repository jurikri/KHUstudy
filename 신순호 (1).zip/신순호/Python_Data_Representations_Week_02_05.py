"""
Template - Create a list of words form a string consisting of words separated by spaces
"""

# Uncomment and enter code here

quote = "Bring me a shrubbery"
word_list = quote.split()
print(word_list)


# Output
#['Bring', 'me', 'a', 'shrubbery']