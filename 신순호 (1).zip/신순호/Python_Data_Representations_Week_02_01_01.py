"""
Template- Create a list of the first six primes and print the 2nd, 4th, and 6th
"""
prime_number_list = [2]
prime_number_candit = 3
while len(prime_number_list) < 30:
    for prime_number in prime_number_list:
        if prime_number_candit % prime_number == 0:
            break

    if prime_number_candit % prime_number != 0:
        prime_number_list.append(prime_number_candit)

    prime_number_candit = prime_number_candit + 1

print(prime_number_list)