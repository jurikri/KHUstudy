"""
Template - Create a list formed by excluding the first and last items of example_list
"""

# Enter code here

example_list = [2, 3, 5, 7, 11, 13]

# Uncomment and complete
middle_list = example_list[1 : -1]
print(middle_list)


# Output
#[3, 5, 7, 11]
