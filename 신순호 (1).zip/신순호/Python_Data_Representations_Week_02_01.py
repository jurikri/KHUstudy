"""
Template- Create a list of the first six primes and print the 2nd, 4th, and 6th
"""
prime_number_list = [2, 3, 5, 7, 11, 13]
print(prime_number_list[1], prime_number_list[3], prime_number_list[5])
pass

# Output
#3 7 13
