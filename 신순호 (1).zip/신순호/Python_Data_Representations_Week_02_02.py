"""
Template - Create a list formed by the first and last items of example_list
"""

example_list = [2, 3, 5, 7, 11, 13]

# Uncomment and complete

firstlast_list = [example_list[0], example_list[-1]]
print(firstlast_list)


# Output
#[2, 13]
